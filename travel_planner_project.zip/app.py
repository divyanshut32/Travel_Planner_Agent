from flask import Flask, request, jsonify
from planner import generate_itinerary

app = Flask(__name__)

@app.route('/plan', methods=['POST'])
def plan_trip():
    data = request.json
    itinerary = generate_itinerary(data)
    return jsonify(itinerary)

if __name__ == '__main__':
    app.run(debug=True)