def generate_itinerary(user_input):
    # Simulated response from IBM Granite LLM
    return {
        "user": user_input.get("name", "Traveler"),
        "budget": user_input["budget"],
        "itinerary": {
            "day_1": {
                "location": "Shimla",
                "activities": ["Mall Road walk", "Jakhoo Temple"],
                "hotel": "Green Valley",
                "cost": 3500
            },
            "day_2": {
                "location": "Kufri",
                "activities": ["Skiing", "Horse Riding"],
                "hotel": "Snow View",
                "cost": 4000
            }
        }
    }