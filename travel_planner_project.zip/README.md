# Travel Planner Agent

This AI-powered agent helps users plan personalized travel itineraries using IBM Granite and IBM Cloud services.

## Features
- Collects user preferences (budget, destination, etc.)
- Generates itinerary using a simulated IBM Granite prompt
- Returns JSON-formatted travel plans

## Setup
1. Install dependencies:
```
pip install -r requirements.txt
```
2. Run the app:
```
python app.py
```

## API Endpoint
**POST** `/plan`  
**Body:**
```json
{
  "name": "Divyanshu",
  "budget": 40000
}
```